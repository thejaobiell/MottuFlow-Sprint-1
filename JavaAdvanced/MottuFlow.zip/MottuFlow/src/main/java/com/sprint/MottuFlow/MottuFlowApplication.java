package com.sprint.MottuFlow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MottuFlowApplication {

	public static void main(String[] args) {
		SpringApplication.run(MottuFlowApplication.class, args);
	}
}