package com.sprint.MottuFlow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MottuFlowApplicationTests {

	@Test
	void contextLoads() {
	}

}
